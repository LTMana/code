## 心情笔记
## 用微信setStorage做的一个demo
## 微信小程序官方文档
## https://mp.weixin.qq.com/debug/wxadoc/dev/
## 微信小程序官方工具下载
## https://mp.weixin.qq.com/debug/wxadoc/dev/devtools/download.html