//...定义配置文件
#import <UIKit/UIKit.h>

NSString *Sysfkgis_gateway; //...搜索
NSString *Sysfmappmg_cn;    //...中文瓦片地图
NSString *Sysfmappmg_en;    //...英文瓦片地图
NSString *Sysdtmimg;        //...路况
NSString *Systrack;         //...轨迹