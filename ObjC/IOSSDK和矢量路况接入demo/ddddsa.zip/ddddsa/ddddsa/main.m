//
//  main.m
//  ddddsa
//
//  Created by 刘博通 on 16/7/26.
//  Copyright © 2016年 ltcom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
