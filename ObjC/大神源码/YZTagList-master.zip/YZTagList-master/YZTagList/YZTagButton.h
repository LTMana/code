//
//  YZTagButton.h
//  Hobby
//
//  Created by yz on 16/8/14.
//  Copyright © 2016年 yz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZTagButton : UIButton

@property (nonatomic, assign) CGFloat margin;

@end
