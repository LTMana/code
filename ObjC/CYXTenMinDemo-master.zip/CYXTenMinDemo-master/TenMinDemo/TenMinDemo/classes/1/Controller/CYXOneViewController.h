//
//  CYXOneViewController.h
//  
//
//  Created by Macx on 15/9/4.
//  Copyright (c) 2015年 CYX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYXOneViewController : UITableViewController

@end
